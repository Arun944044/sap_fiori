sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(Controller, JSONModel, MessageBox) {
	"use strict";

	return Controller.extend("GP_FileUpload.controller.View1", {
		onInit: function() {
			var that = this;
			jQuery.sap.addUrlWhitelist("blob");
			var oModel = new JSONModel();
			that.getView().setModel(oModel);
			var ExcelModel = new sap.ui.model.json.JSONModel();
			that.getView().setModel(ExcelModel, "ExcelModel");
			var columnModel = new JSONModel();
			that.getView().setModel(columnModel, "columnModel");
			var inputmodel = new JSONModel({
				xlsxbase64: "",
				PDFbase64: "",
				PNGbase64: "",
				pageName: ""
			});
			that.getView().setModel(inputmodel, "BASE64Model");
			var titleModel = new JSONModel({
				Fragmenttitle: "",
				Fragmenttitle1: "",
				Fragmenttitle2: ""
			});
			that.getView().setModel(titleModel, "titleModel");
		},
		XLSXupload: function(oEvent) {
			var that = this;

			// var filetype = this.getView().byId("FileUploaderid").getFileType();
			var path = oEvent.getParameters("newValue").newValue;
			if (path.split(".")[1] === 'xlsx') {
				var oFileUploader = that.getView().byId("FileUploaderid");
				// Returns the DOM Element that should get the focus or null if there's no such element currently.
				// To be overwritten by the specific control method.
				var oFile = oFileUploader.getFocusDomRef().files[0];
				//To check the File type of uploaded File.
				that.typeXLSX();
			} else {

				MessageBox.warning("Please Choose XLSX File");
				that.getView().getModel("BASE64Model").setProperty("/emptystring");
			}
		},
		typeXLSX: function() {
			var that = this;
			var oFileUploader = that.getView().byId("FileUploaderid");
			var file = oFileUploader.getFocusDomRef().files[0];
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function(evt) {
					that.data = evt.target.result;
					var workbook = XLSX.read(that.data, {
						// Base64 means Binary to text encoding scheme
						type: 'binary'

					});
					workbook.SheetNames.forEach(function(sheetName) {
						excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
					});
					that.getView().getModel("ExcelModel").setData(excelData);
					that.getView().getModel("ExcelModel").refresh(true);
					that.generateTablexlsx();
				};
				reader.onerror = function(ex) {
					console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		},
		/*Function to create the table Dynamically for xlsx file*/
		generateTablexlsx: function() {
			var that = this;
			if (!this.oDialog) {
				this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
				this.getView().addDependent(this.oDialog);
				sap.ui.getCore().byId("tableID").setVisible(true);
				sap.ui.getCore().byId("PDFtableID").setVisible(false);
				sap.ui.getCore().byId("JPGi2").setVisible(false);
				sap.ui.getCore().byId("inp1").setVisible(false);
				sap.ui.getCore().byId("inp2").setVisible(false);
				that.getView().getModel("BASE64Model").setProperty("/pageName", "XLSX DATA");
			}

			this.oDialog.open();

			// var oTable = that.getView().byId("tableID");
			var oTable = sap.ui.getCore().byId("tableID");
			var oModel = that.getView().getModel("ExcelModel");
			var oModelData = oModel.getProperty("/");
			var oColumns = Object.keys(oModelData[0]);
			var oColumnNames = [];
			$.each(oColumns, function(i, value) {
				oColumnNames.push({
					Text: oColumns[i]
				});
			});
			var columnmodel = that.getView().getModel("columnModel");
			columnmodel.setProperty("/", oColumnNames);
			var oTemplate = new sap.m.Column({
				header: new sap.m.Label({
					text: "{columnModel>Text}"
				})
			});
			oTable.bindAggregation("columns", "columnModel>/", oTemplate);
			oTable.bindItems({
				path: "/",
				template: new sap.m.ColumnListItem({
					cells: oColumnNames.map(function(columnConfig) {
						return new sap.m.Text({
							text: "{" + columnConfig.Text + "}"
						});
					})
				})
			});
			// Set the model to the table
			oTable.setModel(oModel);
		},
		PDFupload: function(oEvent) {
			var that = this;
			var path1 = oEvent.getParameters("newValue").newValue;
			if (path1.split(".")[1] === 'pdf') {
				var oFileUploader = that.getView().byId("PDFid");
				// Returns the DOM Element that should get the focus or null if there's no such element currently.
				// To be overwritten by the specific control method.
				var oFile = oFileUploader.getFocusDomRef().files[0];
				//To check the File type of uploaded File.
				if (!this.oDialog) {
					this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
					this.getView().addDependent(this.oDialog);

					sap.ui.getCore().byId("inp1").setVisible(false);
					sap.ui.getCore().byId("JPGi2").setVisible(false);
					sap.ui.getCore().byId("tableID").setVisible(false);
					sap.ui.getCore().byId("PDFtableID").setVisible(true);
					sap.ui.getCore().byId("inp2").setVisible(false);
					that.getView().getModel("BASE64Model").setProperty("/pageName", "PDF DATA");

				}
				this.oDialog.open();

			} else {

				MessageBox.warning("Please Choose PDF File");
				that.getView().getModel("BASE64Model").setProperty("/emptystring1");
			}

			var oFileuploder = this.getView().byId("PDFid");
			var domRef = oFileuploder.getFocusDomRef();
			var files = oEvent.getParameter("files"); //domRef.files;
			var f = files[0]; // FileList object   
			if (f.type.includes("pdf")) {
				var url = URL.createObjectURL(f);
				sap.ui.getCore().byId("PDFtableID").setSource(url);
				that.typePDF();
			}

		},
		typePDF: function() {
			var that = this;
			var oFileUploader = that.getView().byId("PDFid");
			var file = oFileUploader.getFocusDomRef().files[0];
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function(evt) {
					that.datapdf = evt.target.result;
					var workbook = PDF.read(that.datapdf, {
						// Base64 means Binary to text encoding scheme
						type: 'binary'

					});
					workbook.SheetNames.forEach(function(sheetName) {
						excelData = PDF.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
					});
					that.getView().getModel("ExcelModel").setData(excelData);
					that.getView().getModel("ExcelModel").refresh(true);
					that.generateTablepdf();
				};
				reader.onerror = function(ex) {
					console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		},
		JPGupload: function(oEvent) {
			var that = this;
			var path1 = oEvent.getParameters("newValue").newValue;
			if (path1.split(".")[1] === 'png' || path1.split(".")[1] === 'jpg') {
				var oFileUploader = that.getView().byId("JPGid");
				// Returns the DOM Element that should get the focus or null if there's no such element currently.
				// To be overwritten by the specific control method.
				var oFile = oFileUploader.getFocusDomRef().files[0];
				//To check the File type of uploaded File.
				if (!this.oDialog) {
					this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
					this.getView().addDependent(this.oDialog);

					sap.ui.getCore().byId("inp1").setVisible(false);
					sap.ui.getCore().byId("JPGi2").setVisible(true);
					sap.ui.getCore().byId("tableID").setVisible(false);
					sap.ui.getCore().byId("PDFtableID").setVisible(false);
					sap.ui.getCore().byId("inp2").setVisible(false);
					that.getView().getModel("BASE64Model").setProperty("/pageName", "JPG DATA");
				}
				this.oDialog.open();

			} else {

				MessageBox.warning("Please Choose JPG File");
				that.getView().getModel("BASE64Model").setProperty("/emptystring2");
			}

			var oFileuploder = this.getView().byId("JPGid");
			var domRef = oFileuploder.getFocusDomRef();
			var files = oEvent.getParameter("files"); //domRef.files;
			var f = files[0]; // FileList object   
			if (f.type.includes("image") || f.type.includes("jpg")) {
				var url = URL.createObjectURL(f);
				sap.ui.getCore().byId("JPGi2").setSrc(url);
				that.typeJPG();
			}

		},
		typeJPG: function() {
			var that = this;
			var oFileUploader = that.getView().byId("JPGid");
			var file = oFileUploader.getFocusDomRef().files[0];
			var excelData = {};
			if (file && window.FileReader) {
				var reader = new FileReader();
				reader.onload = function(evt) {
					that.datajpg = evt.target.result;
					var workbook = JPG.read(that.datajpg, {
						// Base64 means Binary to text encoding scheme
						type: 'binary'

					});
					workbook.SheetNames.forEach(function(sheetName) {
						excelData = JPG.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
					});
					that.getView().getModel("ExcelModel").setData(excelData);
					that.getView().getModel("ExcelModel").refresh(true);
					that.generateTablepdf();
				};
				reader.onerror = function(ex) {
					console.log(ex);
				};
				reader.readAsBinaryString(file);
			}
		},
		onClose: function() {
			this.oDialog.close();
			this.oDialog.destroy();
			this.oDialog = null;
		},
		baseXLSX: function() {
			var that = this;
			var data = that.data;
			if (data !== undefined) {
				that.getView().getModel("BASE64Model").setProperty("/xlsxbase64", data);
				if (!this.oDialog) {
					this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
					this.getView().addDependent(this.oDialog);

					sap.ui.getCore().byId("inp1").setVisible(true);
					sap.ui.getCore().byId("JPGi2").setVisible(false);
					sap.ui.getCore().byId("tableID").setVisible(false);
					sap.ui.getCore().byId("PDFtableID").setVisible(false);
					sap.ui.getCore().byId("inp2").setVisible(false);
					sap.ui.getCore().byId("inp3").setVisible(false);
				}
				this.oDialog.open();
			} else {
				MessageBox.warning("Please Choose  File");
			}
		},
		basePDF: function() {
			var that = this;
			var data = that.datapdf;
			if (data !== undefined) {
				that.getView().getModel("BASE64Model").setProperty("/PDFbase64", data);
				if (!this.oDialog) {
					this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
					this.getView().addDependent(this.oDialog);

					sap.ui.getCore().byId("inp1").setVisible(false);
					sap.ui.getCore().byId("JPGi2").setVisible(false);
					sap.ui.getCore().byId("tableID").setVisible(false);
					sap.ui.getCore().byId("PDFtableID").setVisible(false);
					sap.ui.getCore().byId("inp2").setVisible(true);
					sap.ui.getCore().byId("inp3").setVisible(false);
				}
				this.oDialog.open();
			} else {
				MessageBox.warning("Please Choose  File");
			}

		},
		basePNG: function() {
			var that = this;
			var data = that.datajpg;
			if (data !== undefined) {
				that.getView().getModel("BASE64Model").setProperty("/PNGbase64", data);
				if (!this.oDialog) {
					this.oDialog = sap.ui.xmlfragment("GP_FileUpload.view.fileuploader", this);
					this.getView().addDependent(this.oDialog);

					sap.ui.getCore().byId("inp1").setVisible(false);
					sap.ui.getCore().byId("JPGi2").setVisible(false);
					sap.ui.getCore().byId("tableID").setVisible(false);
					sap.ui.getCore().byId("PDFtableID").setVisible(false);
					sap.ui.getCore().byId("inp2").setVisible(false);
					sap.ui.getCore().byId("inp3").setVisible(true);

				}
				this.oDialog.open();
			} else {
				MessageBox.warning("Please Choose  File");
			}

		},
		onCancel: function() {
			var that = this;
			var xlsx = that.getView().byId("FileUploaderid");
			var pdf = that.getView().byId("PDFid");
			var jpg = this.getView().byId("JPGid");
			xlsx.clear();
			pdf.clear();
			jpg.clear();
		}

	});
});